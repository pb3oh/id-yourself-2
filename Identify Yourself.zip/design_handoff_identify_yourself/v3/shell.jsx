/* Shell: Router, TopBar, Nav, Footer, Tweaks */
const { useState, useEffect, useRef, useMemo } = React;

/* -------- ROUTER (hash-based, persisted) -------- */
function useRoute() {
  const parse = () => {
    const h = window.location.hash.replace(/^#\/?/, "") || "home";
    const [path, ...rest] = h.split("/");
    return { path, sub: rest.join("/") };
  };
  const [route, setRoute] = useState(parse());
  useEffect(() => {
    const onHash = () => { setRoute(parse()); window.scrollTo({ top: 0, behavior: "instant" }); };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  return route;
}
function go(path) { window.location.hash = "#/" + path; }
window.go = go;

function Link({ to, children, className, style, onClick }) {
  return <a className={className} style={style} href={"#/" + to} onClick={(e) => { if (onClick) onClick(e); }}>{children}</a>;
}
window.Link = Link;

/* -------- TOP BAR -------- */
function TopBar() {
  return (
    <div className="topbar">
      <div className="topbar-inner">
        <div><span className="dot"></span>Now taking summer & Q4 swag projects</div>
        <div className="topbar-links topbar-hide">
          <Link to="about-us">Outer Banks, NC</Link>
          <a href="tel:8773031049">877-303-1049</a>
          <Link to="contact-us">hello@idyourself.com</Link>
        </div>
      </div>
    </div>
  );
}
window.TopBar = TopBar;

/* -------- NAV -------- */
function Nav() {
  return (
    <nav className="nav">
      <div className="nav-inner">
        <Link to="home" className="logo">
          <span className="logo-mark"><span>id.</span></span>
          <span className="logo-wm">
            <span className="t1">Identify Yourself</span>
            <span className="t2">Branded · Since 2004</span>
          </span>
        </Link>
        <div className="nav-links">
          <div className="nav-item">
            <a><span>About</span><span className="caret">▾</span></a>
            <div className="nav-menu">
              <Link to="about-us">About Us</Link>
              <Link to="meet-the-crew">Meet the Crew</Link>
              <Link to="client-shout-outs">Client Shout-outs</Link>
              <Link to="careers">Careers</Link>
            </div>
          </div>
          <div className="nav-item">
            <a><span>What We Do</span><span className="caret">▾</span></a>
            <div className="nav-menu wide">
              <Link to="services">All Services</Link>
              <Link to="brands-we-carry">Brands We Carry</Link>
              {ID.SERVICES.slice(0, 10).map(s => <Link key={s.slug} to={"services/" + s.slug}>{s.title}</Link>)}
            </div>
          </div>
          <div className="nav-item">
            <a><span>News + Blog</span><span className="caret">▾</span></a>
            <div className="nav-menu">
              <Link to="news">News</Link>
              <Link to="blog">Blog</Link>
            </div>
          </div>
          <div className="nav-item">
            <a><span>Shop</span><span className="caret">▾</span></a>
            <div className="nav-menu">
              <Link to="shop">All Products</Link>
              <Link to="signature-collection">Signature Collection</Link>
            </div>
          </div>
          <div className="nav-item">
            <a><span>Contact</span><span className="caret">▾</span></a>
            <div className="nav-menu">
              <Link to="contact-us">Contact Us</Link>
              <Link to="credit-application">Credit Application</Link>
              <Link to="policies">Policies</Link>
              <Link to="product-safety">Product Safety</Link>
            </div>
          </div>
        </div>
        <div className="nav-cta">
          <a className="phone" href="tel:8773031049">877.303.1049</a>
          <Link to="contact-us" className="btn btn-primary">Get Started <span className="arrow">→</span></Link>
        </div>
      </div>
    </nav>
  );
}
window.Nav = Nav;

/* -------- FOOTER -------- */
function Footer() {
  return (
    <footer className="foot">
      <div className="wrap">
        <div className="foot-top">
          <div>Identify<br/><em style={{fontStyle: "italic"}}>Yourself.</em></div>
          <div className="star">✦</div>
        </div>
        <div className="foot-cols">
          <div className="foot-col foot-about">
            <h5>HQ</h5>
            <div className="addr">
              Post Office Box 432<br/>
              6146 North Croatan Hwy<br/>
              Kitty Hawk, NC 27949<br/><br/>
              877.303.1049
            </div>
            <div className="badges">
              <span className="badge">PPB '19</span>
              <span className="badge">PPB '21</span>
              <span className="badge">PPB '22</span>
            </div>
          </div>
          <div className="foot-col">
            <h5>Services</h5>
            {ID.SERVICES.slice(0,6).map(s => <Link key={s.slug} to={"services/" + s.slug}>{s.title}</Link>)}
            <Link to="services">All services →</Link>
          </div>
          <div className="foot-col">
            <h5>About</h5>
            <Link to="about-us">Our story</Link>
            <Link to="meet-the-crew">Meet the crew</Link>
            <Link to="client-shout-outs">Client shout-outs</Link>
            <Link to="careers">Careers</Link>
            <Link to="brands-we-carry">Brands we carry</Link>
          </div>
          <div className="foot-col">
            <h5>Resources</h5>
            <Link to="shop">Shop</Link>
            <Link to="signature-collection">Signature Collection</Link>
            <Link to="credit-application">Credit application</Link>
            <Link to="product-safety">Product safety</Link>
            <Link to="policies">Policies</Link>
            <Link to="contact-us">Contact</Link>
          </div>
        </div>
        <div className="foot-bottom">
          <div>© 2026 Identify Yourself, LLC</div>
          <div className="socials">
            <a className="social" href="#">f</a>
            <a className="social" href="#">◉</a>
            <a className="social" href="#">in</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
window.Footer = Footer;

/* -------- TWEAKS -------- */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#c7372f",
  "mode": "cream"
}/*EDITMODE-END*/;
const ACCENTS = [
  { name: "ID Red",    c: "#c7372f", d: "#8f221c" },
  { name: "Coastal",   c: "#1e5f7a", d: "#16455a" },
  { name: "Sunrise",   c: "#d97a2b", d: "#a85820" },
  { name: "Forest",    c: "#3f6a4a", d: "#2d4e37" },
  { name: "Plum",      c: "#7c3a58", d: "#5a2942" },
];
function Tweaks() {
  const [open, setOpen] = useState(false);
  const [accent, setAccent] = useState(TWEAK_DEFAULTS.accent);
  const [mode, setMode] = useState(TWEAK_DEFAULTS.mode);
  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === "__activate_edit_mode") setOpen(true);
      if (e.data?.type === "__deactivate_edit_mode") setOpen(false);
    };
    window.addEventListener("message", handler);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", handler);
  }, []);
  useEffect(() => {
    const a = ACCENTS.find(x => x.c === accent) || ACCENTS[0];
    document.documentElement.style.setProperty("--red", a.c);
    document.documentElement.style.setProperty("--red-deep", a.d);
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { accent } }, "*");
  }, [accent]);
  useEffect(() => {
    if (mode === "cream") { document.documentElement.style.setProperty("--bg", "#f4efe8"); document.documentElement.style.setProperty("--bg-2", "#ece5db"); document.documentElement.style.setProperty("--ink", "#171312"); }
    else if (mode === "white") { document.documentElement.style.setProperty("--bg", "#fafafa"); document.documentElement.style.setProperty("--bg-2", "#f1f1f0"); document.documentElement.style.setProperty("--ink", "#0d0d0d"); }
    else if (mode === "sand") { document.documentElement.style.setProperty("--bg", "#ede3d0"); document.documentElement.style.setProperty("--bg-2", "#e0d4bd"); document.documentElement.style.setProperty("--ink", "#1c1815"); }
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { mode } }, "*");
  }, [mode]);
  if (!open) return null;
  return (
    <div className="tweaks open">
      <div className="tweaks-head">
        <div className="t">Tweaks</div>
        <button onClick={() => setOpen(false)} style={{fontSize: 16, color: "var(--muted)"}}>×</button>
      </div>
      <div className="tweaks-body">
        <div className="grp">
          <label>Accent</label>
          <div className="swatches">
            {ACCENTS.map(a => <div key={a.name} className={"sw" + (accent === a.c ? " on" : "")} style={{background: a.c}} title={a.name} onClick={() => setAccent(a.c)}></div>)}
          </div>
        </div>
        <div className="grp">
          <label>Background</label>
          <div className="tabs">
            {[{k:"cream", l:"Cream"}, {k:"white", l:"Off-white"}, {k:"sand", l:"Sand"}].map(t => (
              <div key={t.k} className={"tab" + (mode === t.k ? " on" : "")} onClick={() => setMode(t.k)}>{t.l}</div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
window.Tweaks = Tweaks;
window.useRoute = useRoute;
