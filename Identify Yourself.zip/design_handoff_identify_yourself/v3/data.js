/* Global shared data for the Identify Yourself site */
window.ID = window.ID || {};

ID.SERVICES = [
  { slug: "custom-apparel",       title: "Custom Apparel",       tag: "01", w: 6, fill: "fill-navy",  caption: "Soft goods \u00b7 print \u00b7 embroidery",
    lede: "Tees, hoodies, caps, polos, and performance wear \u2014 decorated with the method that actually fits your brand and your fabric.",
    features: [
      { n: "01", h: "Screen print",     p: "Plastisol and waterbased for vivid, durable prints on cotton and poly-blends." },
      { n: "02", h: "Embroidery",       p: "3D puff, tackle twill, appliqu\u00e9, and fine detail stitching." },
      { n: "03", h: "DTG & DTF",        p: "Full-color photo-real prints, economical for small runs and on-demand." },
    ] },
  { slug: "company-merch",        title: "Company Merch",        tag: "02", w: 6, fill: "fill-red",   caption: "Drop-worthy branded kit",
    lede: "The drinkware, totes, tech, and trinkets your team actually uses. Sourced thoughtfully, decorated well.",
    features: [
      { n: "01", h: "Curated catalog", p: "Not 50 of everything \u2014 the 5 best in each category for your budget and use case." },
      { n: "02", h: "Custom sourcing", p: "When nothing off the shelf fits, we'll design and manufacture it." },
      { n: "03", h: "Sample program",  p: "Touch it before you buy a thousand. We'll ship samples for review." },
    ] },
  { slug: "incentives-and-gifts", title: "Incentives & Gifts",   tag: "03", w: 4, fill: "fill-sand",  caption: "Executive + holiday",
    lede: "Premium gifts that say \"we value this relationship\" \u2014 not \"we have a budget to spend.\"",
    features: [
      { n: "01", h: "Gift design",     p: "Curated sets with thoughtful packaging, custom cards, and pre-sorted kitting." },
      { n: "02", h: "Fulfillment",     p: "One address or a thousand \u2014 we'll ship each recipient individually." },
      { n: "03", h: "Budget tiers",    p: "From $25 to $500+, with curated options at every tier." },
    ] },
  { slug: "warehousing-and-custom-kitting", title: "Warehousing & Kitting", tag: "04", w: 4, fill: "fill-olive", caption: "Pick \u00b7 pack \u00b7 ship",
    lede: "Your inventory, our warehouse. We'll store, pick, kit, and ship \u2014 nationwide, on-demand.",
    features: [
      { n: "01", h: "Secure storage",  p: "Climate-controlled warehouse space with real-time inventory tracking." },
      { n: "02", h: "Custom kits",     p: "Build branded welcome boxes, event swag kits, and mailers to order." },
      { n: "03", h: "Ship on demand", p: "Trigger fulfillment from your HRIS, CRM, or manual request." },
    ] },
  { slug: "print-collateral-and-packaging", title: "Print Collateral & Packaging", tag: "05", w: 4, fill: "fill-cream", caption: "Collateral + box design",
    lede: "Business cards, brochures, mailers, custom boxes, tissue, tape \u2014 print that makes the unboxing.",
    features: [
      { n: "01", h: "Offset & digital", p: "Full-color on specialty stocks, foils, embosses, letterpress." },
      { n: "02", h: "Custom packaging", p: "Mailer boxes, rigid boxes, product packaging \u2014 designed and sourced." },
      { n: "03", h: "Short-run friendly", p: "No 5,000-unit minimums \u2014 we'll run 100 if that's what you need." },
    ] },
  { slug: "online-stores",        title: "Online Stores",        tag: "06", w: 4, fill: "fill-ink",   caption: "Storefronts, fulfilled",
    lede: "Company stores and swag shops \u2014 branded to you, managed by us, shipped to your people.",
    features: [
      { n: "01", h: "Branded store",   p: "Custom-skinned storefront with your logo, colors, and product line." },
      { n: "02", h: "Payroll deduct",  p: "Employee-pay options, budget allotments, and gift-card redemption." },
      { n: "03", h: "Full fulfillment", p: "Orders go to us. We produce, pack, and ship. No inventory on your side." },
    ] },
  { slug: "awards-and-recognition", title: "Awards & Recognition", tag: "07", w: 4, fill: "fill-rust", caption: "Employee moments",
    lede: "Plaques, crystal, acrylic, metal \u2014 for the milestones that earn more than a Slack emoji.",
    features: [
      { n: "01", h: "Custom design",   p: "Shape, material, engraving, color fill \u2014 your award, not a catalog pick." },
      { n: "02", h: "Rush available",  p: "Event next week? We'll make it happen \u2014 with careful prep and proofing." },
      { n: "03", h: "Program builds",  p: "Years-of-service, top-performer, sales leaderboards \u2014 the whole program." },
    ] },
  { slug: "tradeshow-displays",   title: "Tradeshow Displays",   tag: "08", w: 4, fill: "fill-navy",  caption: "Booths that command rooms",
    lede: "Backwalls, tables, pop-ups, tension fabric, hanging signs \u2014 kitted in a single shipping case.",
    features: [
      { n: "01", h: "Turnkey booths",  p: "10\u00d710 to 20\u00d720 with flooring, lighting, and graphic panels." },
      { n: "02", h: "Portable kits",   p: "Single-case systems your team can pack, ship, and set up solo." },
      { n: "03", h: "Graphics only",   p: "Bring the hardware, we'll print the graphics \u2014 perfectly fit." },
    ] },
  { slug: "creative-services",    title: "Creative Services",    tag: "09", w: 4, fill: "fill-teal",  caption: "Design, direction, identity",
    lede: "Our in-house design team. Logos, brand guides, apparel mockups, packaging, and campaign creative.",
    features: [
      { n: "01", h: "Logo & identity", p: "Mark, type, color system, and usage guidelines." },
      { n: "02", h: "Art direction",   p: "Look books, campaign concepts, apparel mockups, and product styling." },
      { n: "03", h: "Production-ready", p: "Everything we design is built to be printed, embroidered, or embossed." },
    ] },
  { slug: "retail-merchandise",   title: "Retail Merchandise",   tag: "10", w: 4, fill: "fill-sand",  caption: "Store-floor ready",
    lede: "For restaurants, hotels, parks, and venues \u2014 merch that sits in the store and sells like product.",
    features: [
      { n: "01", h: "Retail-grade",    p: "Hang tags, barcodes, poly-bags, and retail-ready packaging." },
      { n: "02", h: "Minimum inventory", p: "Low-MOQ production so you don't over-order on unproven items." },
      { n: "03", h: "Trend-aware",     p: "What's selling in actual retail \u2014 not last year's catalog." },
    ] },
  { slug: "overseas-sourcing",    title: "Global Sourcing",      tag: "11", w: 4, fill: "fill-ink",   caption: "Custom, made direct",
    lede: "Overseas production for true custom items \u2014 when domestic can't hit the spec or the quantity.",
    features: [
      { n: "01", h: "Factory-direct",  p: "Vetted overseas manufacturing partners with QC on the ground." },
      { n: "02", h: "Custom tooling",  p: "Molds, dies, and build-to-spec components for original products." },
      { n: "03", h: "Freight handled", p: "Ocean or air, customs, delivery \u2014 we manage the whole chain." },
    ] },
  { slug: "large-format-printing", title: "Large Format Printing", tag: "12", w: 4, fill: "fill-red",  caption: "Big graphics \u00b7 big impact",
    lede: "Banners, wall wraps, vehicle graphics, window clings, event signage \u2014 anything over 24 inches.",
    features: [
      { n: "01", h: "Indoor & outdoor", p: "UV-stable inks rated for 3\u20135 years outdoor without fading." },
      { n: "02", h: "Substrates",       p: "Vinyl, fabric, acrylic, foam-core, coroplast, and aluminum panels." },
      { n: "03", h: "Install-ready",    p: "Grommets, pole pockets, adhesive backing, or full install service." },
    ] },
];

ID.TESTIMONIALS = [
  { q: "We took our display stand to an industry show last week and received so many compliments. Some people said we had the best-looking booth at the show.", name: "Jenn", loc: "Kitty Hawk, NC" },
  { q: "Love the colors and the new-and-improved design. We haven't finished unpacking the shirts and we're already selling them like crazy.", name: "Debbie", loc: "Engelhard, NC" },
  { q: "The coozies look amazing \u2014 such a hit, and everyone is super excited about them. We'll be ordering more.", name: "Alzie", loc: "Jackson Hole, WY" },
  { q: "Our graphic guy used to run a screen-printing business and even he was highly impressed with the shirts.", name: "M. Welch", loc: "Norfolk, VA" },
  { q: "Got the Fan-Fans delivered yesterday. They look great. Our soccer game is nationally broadcast tonight \u2014 they'll be everywhere.", name: "J. Chandler", loc: "Hampton, VA" },
  { q: "Hey Chris! They look so awesome! Thank you and your team for the quick turnaround and (as usual) great quality work.", name: "A. Gray", loc: "Reston, VA" },
  { q: "We enjoyed meeting you face to face and genuinely appreciate the thorough follow-up and always great customer service.", name: "K. Yevak", loc: "Hampton, VA" },
];

ID.BRANDS = [
  { n: "adidas",       c: "Apparel",     style: "lower-bold" },
  { n: "BROOKSTONE",   c: "Gifts",       style: "serif-cap" },
  { n: "Calvin Klein", c: "Apparel",     style: "thin-cap" },
  { n: "Champion",     c: "Apparel",     style: "script" },
  { n: "Dickies",      c: "Workwear",    style: "block" },
  { n: "Eddie Bauer",  c: "Outdoor",     style: "serif" },
  { n: "FLEXFIT",      c: "Headwear",    style: "condensed" },
  { n: "GILDAN",       c: "Basics",      style: "block" },
  { n: "Hurley",       c: "Surf",        style: "italic-bold" },
  { n: "IZOD",         c: "Golf",        style: "serif-cap" },
  { n: "NIKE",         c: "Performance", style: "italic-bold" },
  { n: "OAKLEY",       c: "Eyewear",     style: "condensed" },
  { n: "SanMar",       c: "Apparel",     style: "lower-bold" },
  { n: "SPY",          c: "Eyewear",     style: "block" },
  { n: "Titleist",     c: "Golf",        style: "serif" },
  { n: "VAN HEUSEN",   c: "Dress",       style: "thin-cap" },
  { n: "Zippo",        c: "Gifts",       style: "script" },
  { n: "YETI",         c: "Drinkware",   style: "block" },
  { n: "Carhartt",     c: "Workwear",    style: "block" },
  { n: "Patagonia",    c: "Outdoor",     style: "serif" },
  { n: "Moleskine",    c: "Paper",       style: "lower-bold" },
  { n: "Stanley",      c: "Drinkware",   style: "block" },
  { n: "Cutter & Buck", c: "Golf",       style: "serif" },
  { n: "Yeti \u25c6",   c: "Coolers",     style: "italic-bold" },
];

ID.CREW = [
  { name: "Chris Martini",   role: "Founder \u00b7 CEO",             dept: "Leadership", ext: "201", initials: "CM", fill: "fill-navy" },
  { name: "Nancy Rollins",   role: "Sales Director",                 dept: "Sales",      ext: "205", initials: "NR", fill: "fill-red"  },
  { name: "Casey Nguyen",    role: "Account Lead",                   dept: "Sales",      ext: "213", initials: "CN", fill: "fill-sand" },
  { name: "Derek Monroe",    role: "Production Manager",             dept: "Production", ext: "221", initials: "DM", fill: "fill-olive" },
  { name: "Lila Hargrove",   role: "Creative Director",              dept: "Creative",   ext: "231", initials: "LH", fill: "fill-teal" },
  { name: "Marcus Whittaker", role: "Senior Designer",               dept: "Creative",   ext: "235", initials: "MW", fill: "fill-rust" },
  { name: "Ruby Olsen",      role: "Warehouse Lead",                 dept: "Fulfillment", ext: "242", initials: "RO", fill: "fill-ink"  },
  { name: "Tate Brennan",    role: "Sourcing & Logistics",           dept: "Sourcing",   ext: "248", initials: "TB", fill: "fill-cream" },
  { name: "Iris Calloway",   role: "Client Success",                 dept: "Sales",      ext: "208", initials: "IC", fill: "fill-navy" },
  { name: "Ben Okafor",      role: "Print Technician",               dept: "Production", ext: "225", initials: "BO", fill: "fill-red" },
  { name: "June Pritchard",  role: "Embroidery Lead",                dept: "Production", ext: "227", initials: "JP", fill: "fill-olive" },
  { name: "Sam Delacroix",   role: "Operations & Finance",           dept: "Ops",        ext: "202", initials: "SD", fill: "fill-sand" },
];

ID.SHOUT_OUTS = ID.TESTIMONIALS.concat([
  { q: "We've been working with Identify Yourself for 6 years and every order has been handled with care. They just get our brand.", name: "R. Thompson", loc: "Raleigh, NC" },
  { q: "The online store they built for us changed how we do employee swag. Zero overhead on our side, thousand orders a year going out.", name: "B. Patel", loc: "Richmond, VA" },
  { q: "Fast, friendly, and always willing to figure something out. They feel like part of our marketing team.", name: "C. Ramirez", loc: "Atlanta, GA" },
]);

ID.NEWS = [
  { cat: "Company",  date: "Mar 12, 2026", title: "ID Yourself named PPB Greatest Companies to Work For, 4th year running", excerpt: "Industry recognition for team culture, retention, and client service \u2014 the fourth consecutive year on the PPB list.", fill: "fill-red"   },
  { cat: "Expansion", date: "Feb 02, 2026", title: "New warehouse space opens on the Outer Banks", excerpt: "Adding 8,000 sq ft of climate-controlled storage and kitting capacity for program clients.", fill: "fill-navy" },
  { cat: "Awards",   date: "Jan 18, 2026", title: "SAAC Pyramid Award nomination for custom apparel program", excerpt: "Our work with a coastal resort group earned a regional creative nomination this year.", fill: "fill-sand"  },
  { cat: "Team",     date: "Dec 08, 2025", title: "Welcoming three new creatives to the studio", excerpt: "Designers, one sourcing lead \u2014 meet the latest additions to the ID Yourself crew.", fill: "fill-olive" },
  { cat: "Product",  date: "Nov 22, 2025", title: "Signature Collection drops new coastal capsule", excerpt: "Limited-edition apparel and drinkware, inspired by the Outer Banks in winter.", fill: "fill-rust"  },
  { cat: "Community", date: "Oct 04, 2025", title: "Partnering with Dare County schools on spirit wear", excerpt: "A new multi-year program to outfit local athletic and academic teams.", fill: "fill-teal"  },
];

ID.BLOG = [
  { cat: "How-to",    date: "Mar 28, 2026", title: "The five merch items employees actually keep (and five they quietly toss)", excerpt: "Budget tip: stop buying the ones in category two.", read: "6 min", fill: "fill-sand"  },
  { cat: "Industry",  date: "Mar 14, 2026", title: "Decoration methods, decoded: when to screen print vs. embroider vs. DTG", excerpt: "A field guide to getting your logo on the right substrate \u2014 without the guesswork.", read: "9 min", fill: "fill-navy"  },
  { cat: "Case study", date: "Feb 20, 2026", title: "How a regional brewery outfitted 40 locations in six weeks", excerpt: "Program design, kitting, shipping \u2014 the whole rollout.", read: "7 min", fill: "fill-rust"  },
  { cat: "How-to",    date: "Feb 07, 2026", title: "Kitting 101: building a welcome box that doesn't feel like one", excerpt: "The difference between a gift and a bag-of-stuff is 90% intention.", read: "5 min", fill: "fill-teal"  },
  { cat: "Opinion",   date: "Jan 24, 2026", title: "Sustainability in promo: what's greenwashing, what's real", excerpt: "A practical guide to asking the right questions.", read: "8 min", fill: "fill-olive" },
  { cat: "Industry",  date: "Jan 10, 2026", title: "Lead times in 2026: what to expect for Q4 production", excerpt: "Plan backwards from your event date \u2014 here's how.", read: "4 min", fill: "fill-red"   },
];

ID.PRODUCTS = [
  { name: "Coastal Crew Tee",      sub: "Heavyweight cotton, garment-dyed",       price: "from $18",  cat: "Apparel",  fill: "fill-navy" },
  { name: "Signature Hoodie",      sub: "French terry, embroidered crest",        price: "from $42",  cat: "Apparel",  fill: "fill-ink"  },
  { name: "5-Panel Camper Cap",    sub: "Cotton twill, woven patch",              price: "from $16",  cat: "Headwear", fill: "fill-sand" },
  { name: "Tumbler, 20oz",         sub: "Double-wall stainless, laser etched",    price: "from $24",  cat: "Drinkware", fill: "fill-red"  },
  { name: "Waxed Canvas Tote",     sub: "Heavyweight duck, leather handle",       price: "from $32",  cat: "Bags",     fill: "fill-olive" },
  { name: "Field Notebook",        sub: "Letterpress cover, 64pp",                price: "from $9",   cat: "Paper",    fill: "fill-cream" },
  { name: "Dad Cap, Unstructured", sub: "Washed cotton, embroidered",             price: "from $14",  cat: "Headwear", fill: "fill-rust" },
  { name: "Quarter-Zip Fleece",    sub: "Sherpa lining, left-chest embroidery",   price: "from $54",  cat: "Apparel",  fill: "fill-teal" },
  { name: "Pint Glass, Set of 2",  sub: "Pad printed, gift boxed",                price: "from $22",  cat: "Drinkware", fill: "fill-navy" },
  { name: "Welcome Box, Onboarding", sub: "Curated kit with custom packaging",    price: "from $85",  cat: "Kits",     fill: "fill-red"  },
  { name: "Enamel Pin Set",        sub: "Hard enamel, butterfly clutch",          price: "from $6",   cat: "Accessories", fill: "fill-sand" },
  { name: "Crystal Award",         sub: "Cut glass, deep etched",                 price: "from $75",  cat: "Awards",   fill: "fill-ink"  },
];

ID.FAQ = [
  { q: "What's your minimum order?",           a: "It varies by product. Screen-printed apparel typically starts at 24 pieces. Embroidery at 12. Drinkware and gifts at 48. For some items we can do runs of 6 \u2014 just ask." },
  { q: "What are typical turnaround times?",   a: "For in-stock decoration: 10\u201314 business days after art approval. Custom sourcing: 6\u201310 weeks. Rush service is available on most orders for a 15% expedite fee." },
  { q: "Do you work with clients nationwide?", a: "Yes. We're based on the Outer Banks of North Carolina but ship projects across all 50 states. Most client conversations happen by email, phone, and video." },
  { q: "Can you help design something from scratch?", a: "Yes \u2014 our Creative Services team handles logos, identity, apparel mockups, and packaging. Many of our clients come to us with a napkin sketch." },
  { q: "Do you offer sustainable or eco-friendly products?", a: "A growing portion of our catalog \u2014 recycled materials, organic cotton, bluesign-certified apparel, FSC-certified paper. We'll help you spec a fully-eco program." },
  { q: "How do you handle payment?",           a: "Net-30 terms available for approved accounts via credit application. Otherwise: 50% deposit on PO approval, balance on shipment." },
];
