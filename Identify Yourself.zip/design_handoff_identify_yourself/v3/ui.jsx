/* Reusable UI primitives for the Identify Yourself site */

function PageHero({ crumb, eye, title, titleIt, lede, wide }) {
  return (
    <section className={"page-hero" + (wide ? " wide" : "")}>
      <div className="wrap">
        {crumb && <div className="crumb mono">{crumb}</div>}
        {eye && <div className="eye mono"><span className="ldot"></span>{eye}</div>}
        <h1>{title}{titleIt && <> <span className="it">{titleIt}</span></>}</h1>
        {lede && <p className="lede">{lede}</p>}
      </div>
    </section>
  );
}
window.PageHero = PageHero;

function SecHead({ eye, title, titleIt }) {
  return (
    <div className="sec-head">
      <div><div className="label mono"><span className="ldot"></span>{eye}</div></div>
      <h2 className="sec-title">{title} {titleIt && <span className="it">{titleIt}</span>}</h2>
    </div>
  );
}
window.SecHead = SecHead;

function Ticker() {
  const items = ["Apparel", "★", "Merch", "★", "Gifts", "★", "Fulfillment", "★", "Print", "★", "Events", "★", "Awards", "★"];
  const full = [...items, ...items, ...items, ...items];
  return (
    <div className="ticker">
      <div className="ticker-track">
        {full.map((x, i) => <span key={i} className={x === "★" ? "sep" : "item"}>{x}</span>)}
      </div>
    </div>
  );
}
window.Ticker = Ticker;

function ServiceCard({ s }) {
  return (
    <Link to={"services/" + s.slug} className={"svc w-" + s.w}>
      <div className={"svc-media " + s.fill}></div>
      <div className="svc-tag">{s.tag} / {s.title.split(" ")[0]}</div>
      <div className="svc-meta">
        <div className="title">{s.title}</div>
        <div className="num">→ {s.caption}</div>
      </div>
    </Link>
  );
}
window.ServiceCard = ServiceCard;

function TestimonialCarousel({ list }) {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIdx(i => (i + 1) % list.length), 7000);
    return () => clearInterval(t);
  }, [list.length]);
  const t = list[idx];
  return (
    <section className="testi">
      <div className="wrap">
        <SecHead eye="Witness statements" title="Our clients" titleIt="said it first." />
        <div className="testi-card" key={idx}>
          <div className="testi-quote">{t.q}</div>
          <div className="testi-author">
            <div className="name">— {t.name}</div>
            <div className="loc">{t.loc}</div>
          </div>
        </div>
        <div className="testi-nav">
          <div className="testi-dots">
            {list.map((_, i) => <div key={i} className={"tdot" + (i === idx ? " on" : "")} onClick={() => setIdx(i)}></div>)}
          </div>
          <div className="testi-arrows">
            <button className="testi-arrow" onClick={() => setIdx((idx - 1 + list.length) % list.length)}>←</button>
            <button className="testi-arrow" onClick={() => setIdx((idx + 1) % list.length)}>→</button>
          </div>
        </div>
      </div>
    </section>
  );
}
window.TestimonialCarousel = TestimonialCarousel;

function BrandsGrid({ limit }) {
  const list = limit ? ID.BRANDS.slice(0, limit) : ID.BRANDS;
  return (
    <div className="brands-grid">
      {list.map((b, i) => <div key={i} className={"brand " + b.style} data-cat={b.c}>{b.n}</div>)}
    </div>
  );
}
window.BrandsGrid = BrandsGrid;

function ContactCTA() {
  const [discussing, setDiscussing] = useState("New swag");
  const [sent, setSent] = useState(false);
  const chips = ["New swag", "Existing project", "Online store", "Event / tradeshow", "Just browsing"];
  const onSubmit = (e) => { e.preventDefault(); setSent(true); setTimeout(() => setSent(false), 4000); };
  return (
    <section className="contact" id="contact">
      <div className="wrap">
        <div className="contact-grid">
          <div className="contact-side">
            <div className="mono" style={{color: "rgba(255,255,255,0.5)", marginBottom: 20}}>§ Let's talk</div>
            <div className="big">Ready to kick<br/>the <span className="it">promo game</span><br/>up a notch?</div>
            <div className="sub">Give us your info and we'll reach out — usually within one business day with real humans, a real quote, and zero hype.</div>
            <div className="cards">
              <a className="contact-card" href="tel:8773031049"><div><div className="k">Call us</div><div className="v">877.303.1049</div></div><div className="chev">→</div></a>
              <a className="contact-card" href="mailto:hello@idyourself.com"><div><div className="k">Email</div><div className="v">hello@idyourself.com</div></div><div className="chev">→</div></a>
              <div className="contact-card"><div><div className="k">Visit</div><div className="v">6146 N Croatan Hwy, Kitty Hawk NC</div></div><div className="chev">↗</div></div>
            </div>
          </div>
          <form className="form" onSubmit={onSubmit}>
            {sent && <div className="sent-banner">✓ Got it. We'll be in touch within a business day.</div>}
            <div className="row">
              <div className="field"><label>First name <span className="req">*</span></label><input required placeholder="Riley" /></div>
              <div className="field"><label>Last name <span className="req">*</span></label><input required placeholder="Morgan" /></div>
            </div>
            <div className="row">
              <div className="field"><label>Business name</label><input placeholder="Acme Co." /></div>
              <div className="field"><label>Phone <span className="req">*</span></label><input required placeholder="(252) 555-0123" /></div>
            </div>
            <div className="row one"><div className="field"><label>Email <span className="req">*</span></label><input required type="email" placeholder="you@company.com" /></div></div>
            <div className="row one">
              <div className="field">
                <label>I'd like to discuss <span className="req">*</span></label>
                <div className="chip-row">
                  {chips.map(c => <div key={c} className={"chip" + (discussing === c ? " on" : "")} onClick={() => setDiscussing(c)}>{c}</div>)}
                </div>
              </div>
            </div>
            <div className="row one"><div className="field"><label>Tell us about your project <span className="req">*</span></label><textarea required placeholder="Qty, use case, any deadlines, vibe you're going for..."></textarea></div></div>
            <div className="form-foot">
              <div className="fine">We'll reply within 1 business day · No spam, ever</div>
              <button type="submit" className="btn btn-primary">Send it over <span className="arrow">→</span></button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
window.ContactCTA = ContactCTA;
