/* Home + About-family pages */

function HomePage() {
  return (
    <div className="page-fade">
      <section className="hero">
        <div className="wrap">
          <div className="hero-grid">
            <div>
              <div className="hero-eyebrow">
                <div className="line"></div>
                <div className="mono">Since 2004 · Outer Banks, NC</div>
              </div>
              <h1 className="h1">
                Give your brand<br/>
                a <span className="it">face,</span> a voice,<br/>
                a <em className="italic">personality.</em>
              </h1>
              <p className="hero-sub">
                We're a full-service branding studio that takes a thoughtful, full-picture look at your business — and builds the custom apparel, merch, and print that gives it an identity worth remembering.
              </p>
              <div className="hero-ctas">
                <Link to="contact-us" className="btn btn-dark">Start a project <span className="arrow">→</span></Link>
                <Link to="services" className="btn btn-ghost">Explore services</Link>
              </div>
              <div className="hero-meta">
                <div><div className="num">2,400+</div><div className="lbl">Projects delivered</div></div>
                <div><div className="num">3k</div><div className="lbl">Vetted suppliers</div></div>
                <div><div className="num">20yr</div><div className="lbl">In the business</div></div>
              </div>
            </div>
            <div className="hero-visual">
              <div className="placeholder"></div>
              <div className="pill-top">— Lookbook · SS26</div>
              <div className="tape">Branded · Obsessive · Real</div>
              <div className="caption">
                <div><div className="big">Field-tested<br/>on the coast.</div></div>
                <div className="small">IMG 001 / 4×5 product shot</div>
              </div>
            </div>
          </div>
          <div className="hero-marquee">
            <span>Screen Print</span><span>Embroidery</span><span>DTF & DTG</span>
            <span>Laser Etch</span><span>Pad Print</span><span>Sublimation</span><span>Kitting & Fulfillment</span>
          </div>
        </div>
      </section>

      <Ticker />

      <section className="sec">
        <div className="wrap">
          <SecHead eye="What we do" title="Twelve services," titleIt="one crew." />
          <div className="services">
            {ID.SERVICES.slice(0, 9).map(s => <ServiceCard key={s.slug} s={s} />)}
          </div>
          <div className="services-foot">
            <div className="mono muted">Showing 9 of 12 · <Link to="services" style={{color: "var(--red)"}}>See all →</Link></div>
            <Link to="contact-us" className="btn btn-dark">Tell us what you need <span className="arrow">→</span></Link>
          </div>
        </div>
      </section>

      <section className="manifesto">
        <div className="wrap">
          <div className="bg-num">01</div>
          <div className="manifesto-inner">
            <div><div className="mono" style={{color: "rgba(255,255,255,0.5)"}}>§ Who we are</div></div>
            <div>
              <div className="manifesto-body">
                We're not fingerprinting anyone, and we don't moonlight as TV detectives — <span className="mark">though it would be fun.</span> What we are is your partner in cracking the case of brand identity: uncovering the best ways to showcase your business with merch that gets people talking, remembering, connecting.
              </div>
              <div className="manifesto-sub">
                Based in Kitty Hawk on the Outer Banks. Shipping nationwide. Certified by PPB as one of the Greatest Companies to Work For three years running.
              </div>
              <div className="manifesto-stats">
                <div><div className="k">2004</div><div className="v">Founded</div></div>
                <div><div className="k">94%</div><div className="v">Repeat clients</div></div>
                <div><div className="k">48hr</div><div className="v">Avg. first proof</div></div>
                <div><div className="k">3×</div><div className="v">PPB Greatest Co.</div></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <ProcessSection />
      <TestimonialCarousel list={ID.TESTIMONIALS} />

      <section className="sec">
        <div className="wrap">
          <SecHead eye="Licensed to carry" title="The" titleIt="good stuff, already on deck." />
          <BrandsGrid limit={18} />
          <div className="services-foot" style={{marginTop: 28}}>
            <div className="mono muted">Plus 200+ more vendors on request.</div>
            <Link to="brands-we-carry" className="btn btn-ghost">All brands we carry <span className="arrow">→</span></Link>
          </div>
        </div>
      </section>

      <ContactCTA />
    </div>
  );
}
window.HomePage = HomePage;

function ProcessSection() {
  const PROCESS = [
    { n: "01", title: "Discovery", it: "Understand.", desc: "We dig into your brand, your team, your goals. Who's receiving this? What do you want them to feel?" },
    { n: "02", title: "Sourcing", it: "Curate.", desc: "From 3,000+ vetted suppliers, we pull the products, fabrics, and vendors that actually fit — not filler." },
    { n: "03", title: "Design", it: "Refine.", desc: "In-house creative applies your logo like it belongs there. We mock it, you approve it, we make it." },
    { n: "04", title: "Production", it: "Make.", desc: "Screen print, embroidery, laser etching, pad print — the right method for every substrate." },
    { n: "05", title: "Fulfillment", it: "Ship.", desc: "Warehoused, kitted, shipped to one address or a thousand. We handle logistics so you don't have to." },
  ];
  return (
    <section className="sec">
      <div className="wrap">
        <SecHead eye="The process" title="From blank tee to" titleIt="brand moment." />
        <div className="process-list">
          {PROCESS.map((p, i) => (
            <div key={i} className="process-item">
              <div className="num">{p.n}</div>
              <div className="title">{p.title} <span className="it">— {p.it}</span></div>
              <div className="desc">{p.desc}</div>
              <div className="chev">+</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
window.ProcessSection = ProcessSection;

/* ---------- ABOUT US ---------- */
function AboutPage() {
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / About</>} eye="About" title="Twenty years of" titleIt="cracking the brand case." lede="Identify Yourself is a full-service branding and promotional agency based on the Outer Banks of North Carolina — quietly outfitting teams, restaurants, resorts, agencies, and Fortune 500s since 2004." />
      <section className="sec">
        <div className="wrap two-col">
          <div className="rich">
            <h2>Our <span className="it">origin story</span></h2>
            <p>It started with a t-shirt order for a local surf shop. The owner wanted something his crew would actually wear — not the scratchy promo tee that comes free with every convention. Chris Martini took the job, fussed over the fabric weight, hand-delivered the order, and realized this was the real work: <strong>figuring out what makes something worth keeping.</strong></p>
            <p>Twenty years later, we still treat every project like it's one shop, one crew, one moment that matters. We just do it now at the scale of national programs, Fortune 500 rollouts, and thousand-piece welcome-kit deployments.</p>
            <h2>What <span className="it">full-service</span> actually means</h2>
            <p>Most promo companies are catalog resellers. You send them a logo, they send you a quote. Done.</p>
            <p>We're structured differently. We have in-house creative for design and art direction. In-house production for screen print and embroidery. A climate-controlled warehouse for inventory and kitting. A sourcing team for custom, overseas builds. And a sales team that's paid to build relationships, not close line items.</p>
            <ul>
              <li>Discovery and strategy before we even pull a catalog</li>
              <li>Creative direction for brands that don't have in-house design</li>
              <li>Production, warehousing, and fulfillment under one roof</li>
              <li>Dedicated account leads — one point of contact, always</li>
              <li>Sustainable and eco-conscious options across every category</li>
            </ul>
          </div>
          <div style={{position: "sticky", top: 100, alignSelf: "start"}}>
            <div className="hero-visual" style={{aspectRatio: "4/5"}}>
              <div className="placeholder fill-red" style={{opacity: 0.9}}></div>
              <div className="pill-top">Est. 2004 · Kitty Hawk, NC</div>
              <div className="caption">
                <div><div className="big">Twenty years<br/>on the coast.</div></div>
                <div className="small">IMG / HQ exterior</div>
              </div>
            </div>
            <div className="manifesto-stats" style={{marginTop: 32, borderTop: "1px solid var(--line)", color: "var(--ink)"}}>
              <div><div className="k" style={{fontFamily: "var(--serif)", fontSize: 44}}>22yr</div><div className="v mono muted">In business</div></div>
              <div><div className="k" style={{fontFamily: "var(--serif)", fontSize: 44}}>48</div><div className="v mono muted">States served</div></div>
              <div><div className="k" style={{fontFamily: "var(--serif)", fontSize: 44}}>3×</div><div className="v mono muted">PPB honored</div></div>
              <div><div className="k" style={{fontFamily: "var(--serif)", fontSize: 44}}>94%</div><div className="v mono muted">Client retention</div></div>
            </div>
          </div>
        </div>
      </section>
      <TestimonialCarousel list={ID.TESTIMONIALS.slice(0,5)} />
      <ContactCTA />
    </div>
  );
}
window.AboutPage = AboutPage;

/* ---------- MEET THE CREW ---------- */
function CrewPage() {
  const [filter, setFilter] = useState("All");
  const depts = ["All", ...Array.from(new Set(ID.CREW.map(c => c.dept)))];
  const list = filter === "All" ? ID.CREW : ID.CREW.filter(c => c.dept === filter);
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / About / <Link to="about-us">About</Link></>} eye="Meet the crew" title="Happy smiling" titleIt="faces." lede="These are the folks behind every proof, every shipment, every 3pm sample unboxing. A vibrant group of marketing-minded humans from every corner of sales, design, and production." />
      <section className="sec">
        <div className="wrap">
          <div className="shop-top" style={{marginBottom: 40}}>
            <div className="filter-row">
              {depts.map(d => <div key={d} className={"chip" + (filter === d ? " on" : "")} style={{color: filter === d ? "#fff" : "var(--ink)", borderColor: filter === d ? "var(--red)" : "var(--line)"}} onClick={() => setFilter(d)}>{d}</div>)}
            </div>
            <div className="mono muted">{list.length} team members</div>
          </div>
          <div className="crew-grid">
            {list.map((c, i) => (
              <div key={i} className="crew-card">
                <div className="crew-photo">
                  <div className={"ph " + c.fill}></div>
                  <div className="initials">{c.initials}</div>
                  <div className="dept">{c.dept}</div>
                </div>
                <div className="crew-meta">
                  <div>
                    <div className="name">{c.name}</div>
                    <div className="role">{c.role}</div>
                  </div>
                  <div className="ext">ext. {c.ext}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.CrewPage = CrewPage;

/* ---------- CLIENT SHOUT-OUTS ---------- */
function ShoutOutsPage() {
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / About / Client shout-outs</>} eye="Witness statements" title="Kind words," titleIt="loud and clear." lede="The evidence that the work lands. Collected over two decades from the folks who trusted us with their brand." />
      <section className="sec" style={{paddingTop: 60}}>
        <div className="wrap">
          <div style={{display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 20}}>
            {ID.SHOUT_OUTS.map((t, i) => (
              <div key={i} style={{background: i % 3 === 0 ? "var(--red)" : (i % 3 === 1 ? "var(--ink)" : "var(--navy)"), color: "#fff", padding: 36, borderRadius: 8, display: "flex", flexDirection: "column", justifyContent: "space-between", minHeight: 260}}>
                <div className="serif" style={{fontSize: 22, lineHeight: 1.3, fontFamily: "var(--serif)", letterSpacing: "-0.01em"}}>"{t.q}"</div>
                <div style={{marginTop: 24, paddingTop: 20, borderTop: "1px solid rgba(255,255,255,0.2)", display: "flex", justifyContent: "space-between"}}>
                  <div style={{fontWeight: 600, fontSize: 14}}>— {t.name}</div>
                  <div className="mono" style={{opacity: 0.7}}>{t.loc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.ShoutOutsPage = ShoutOutsPage;

/* ---------- CAREERS ---------- */
function CareersPage() {
  const JOBS = [
    { title: "Account Executive", dept: "Sales", type: "Full-time", loc: "Kitty Hawk, NC / Hybrid" },
    { title: "Production Artist", dept: "Creative", type: "Full-time", loc: "Kitty Hawk, NC" },
    { title: "Warehouse Associate", dept: "Fulfillment", type: "Full-time", loc: "Kitty Hawk, NC" },
    { title: "Screen Print Operator", dept: "Production", type: "Full-time", loc: "Kitty Hawk, NC" },
    { title: "Embroidery Technician", dept: "Production", type: "Part-time", loc: "Kitty Hawk, NC" },
  ];
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / About / Careers</>} eye="Join our team" title="Work with good humans" titleIt="on good merch." lede="We're a PPB Greatest Company to Work For three years running. Flexible, collaborative, and paid to do interesting work — occasional beach walks included." />
      <section className="sec">
        <div className="wrap">
          <SecHead eye="Open positions" title="Five open," titleIt="right now." />
          <div className="process-list">
            {JOBS.map((j, i) => (
              <div key={i} className="process-item">
                <div className="num">{String(i + 1).padStart(2, "0")}</div>
                <div className="title">{j.title}</div>
                <div className="desc">
                  <div className="mono muted" style={{marginBottom: 8}}>{j.dept} · {j.type} · {j.loc}</div>
                  Looking for someone organized, thoughtful, and quick on their feet. Apply with a resume and a couple sentences about why.
                </div>
                <div className="chev">→</div>
              </div>
            ))}
          </div>
          <div style={{marginTop: 60, padding: 40, background: "var(--bg-2)", borderRadius: 8}}>
            <div className="mono muted" style={{marginBottom: 12}}>§ Benefits & perks</div>
            <div style={{display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20}}>
              {["Health, dental, vision", "401(k) match", "Flexible PTO", "Team merch program", "Paid beach days", "Monthly team lunches", "Training budget", "Casual dress code"].map((b, i) => (
                <div key={i}>
                  <div className="serif" style={{fontFamily: "var(--serif)", fontSize: 20}}>✦ {b}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.CareersPage = CareersPage;
