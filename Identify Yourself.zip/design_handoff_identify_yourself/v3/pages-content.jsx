/* Content + Contact + Policy pages */

function NewsPage() {
  const POSTS = [
    { date: "Mar 12, 2026", cat: "Awards", title: "Named PPB Greatest Company to Work For — third year running", ex: "We're honored to be recognized again by Promotional Products Business for our team culture, benefits, and work environment." },
    { date: "Feb 28, 2026", cat: "Team", title: "Welcome to the crew: three new faces in sales and production", ex: "Meet the newest additions to our account team and production floor. Each brings a unique mix of experience and energy." },
    { date: "Feb 14, 2026", cat: "Work", title: "Case study: 2,400-piece onboarding kit rollout for a national brand", ex: "How we designed, sourced, kitted, and shipped a white-glove new-hire program across 18 regional offices." },
    { date: "Jan 22, 2026", cat: "Community", title: "Supporting the Outer Banks Chamber's 2026 scholarship fund", ex: "For the seventh consecutive year, we're underwriting two full scholarships for local graduating seniors." },
    { date: "Dec 18, 2025", cat: "Behind the scenes", title: "Inside the holiday gift program: 12 brands, 90 days, one kitting team", ex: "A glimpse at the Q4 rush from our warehouse floor, including tips for getting your 2026 gift program started early." },
    { date: "Nov 05, 2025", cat: "Industry", title: "Why sustainable apparel is finally going mainstream in corporate merch", ex: "Our take on the rise of organic cotton, recycled polyester, and Fair Trade certifications in everyday swag." },
  ];
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / News</>} eye="News" title="What we've been" titleIt="up to." lede="Company news, team announcements, industry commentary, and the occasional story from the Outer Banks coast." />
      <section className="sec">
        <div className="wrap">
          <div className="news-grid">
            {POSTS.map((p, i) => (
              <div key={i} className="news-card">
                <div className="news-cover">
                  <div className={"placeholder " + ["fill-cream", "fill-red", "fill-navy", "fill-ink"][i % 4]}></div>
                  <div className="news-cat">{p.cat}</div>
                </div>
                <div className="news-meta">
                  <div className="mono muted">{p.date}</div>
                  <div className="news-title">{p.title}</div>
                  <div className="news-ex">{p.ex}</div>
                  <div className="news-more">Read more <span className="arrow">→</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.NewsPage = NewsPage;

function BlogPage() {
  const POSTS = [
    { date: "Apr 02, 2026", read: "6 min", cat: "How-to", title: "The difference between screen print, DTG, and DTF — and when to use each", ex: "A practical guide for marketers choosing a decoration method. Covers cost per unit, color range, fabric compatibility, and durability." },
    { date: "Mar 18, 2026", read: "4 min", cat: "Strategy", title: "Onboarding kits that don't end up in the drawer", ex: "Six principles for welcome swag that actually gets used — and keeps new hires representing your brand long after day one." },
    { date: "Mar 04, 2026", read: "5 min", cat: "Design", title: "How to brief a designer for a retail-quality custom hat", ex: "What to include in your brief, what to skip, and how to tell if your decorator is winging it." },
    { date: "Feb 20, 2026", read: "7 min", cat: "Strategy", title: "A planning calendar for your 2026 merch program", ex: "When to start sourcing, proofing, producing, and shipping for every major moment in the year." },
    { date: "Feb 06, 2026", read: "3 min", cat: "How-to", title: "The MOQ question: why minimums exist and how to work around them", ex: "Short answer: setup cost. Long answer: inside the economics of screen print, embroidery, and custom overseas production." },
    { date: "Jan 24, 2026", read: "5 min", cat: "Sustainability", title: "Reading an apparel tag: a field guide to certifications", ex: "GOTS, OEKO-TEX, BCI, Fair Trade — what they mean, what they verify, and what they don't." },
  ];
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / Blog</>} eye="Blog" title="Thinking out loud," titleIt="in public." lede="Essays, how-tos, and field notes from two decades in the branded apparel and promotional products world." />
      <section className="sec">
        <div className="wrap">
          <div className="news-grid">
            {POSTS.map((p, i) => (
              <div key={i} className="news-card">
                <div className="news-cover">
                  <div className={"placeholder " + ["fill-red", "fill-navy", "fill-ink", "fill-cream"][i % 4]}></div>
                  <div className="news-cat">{p.cat}</div>
                </div>
                <div className="news-meta">
                  <div className="mono muted">{p.date} · {p.read} read</div>
                  <div className="news-title">{p.title}</div>
                  <div className="news-ex">{p.ex}</div>
                  <div className="news-more">Read the post <span className="arrow">→</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.BlogPage = BlogPage;

function ContactPage() {
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / Contact</>} eye="Say hello" title="Let's talk" titleIt="merch." lede="Got a project, a question, or a wild idea? Send it our way. We read everything, and we'll reply within one business day — with real humans, real quotes, and zero hype." />
      <ContactCTA />
    </div>
  );
}
window.ContactPage = ContactPage;

function CreditAppPage() {
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / Credit Application</>} eye="Net-30 Credit" title="Credit" titleIt="application." lede="Qualified businesses can apply for Net-30 terms. Fill out the application below and our accounting team will follow up within 3-5 business days." />
      <section className="sec">
        <div className="wrap">
          <div style={{maxWidth: 820, margin: "0 auto", background: "#fff", padding: 48, borderRadius: 8, border: "1px solid var(--line)"}}>
            <div className="mono" style={{color: "var(--red)", fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase", marginBottom: 12}}>Section 1 · Business Info</div>
            <div style={{display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24}}>
              <div className="field"><label>Legal business name <span className="req">*</span></label><input placeholder="Acme Inc." /></div>
              <div className="field"><label>DBA (if different)</label><input placeholder="Acme" /></div>
              <div className="field"><label>Business type <span className="req">*</span></label><select style={{width: "100%", padding: "14px 16px", border: "1px solid var(--line)", background: "#fff", fontFamily: "inherit"}}><option>LLC</option><option>Corporation</option><option>Sole Proprietor</option><option>Non-profit</option></select></div>
              <div className="field"><label>Years in business <span className="req">*</span></label><input placeholder="5" /></div>
              <div className="field"><label>Federal Tax ID <span className="req">*</span></label><input placeholder="XX-XXXXXXX" /></div>
              <div className="field"><label>Annual revenue</label><input placeholder="$1M - $5M" /></div>
            </div>
            <div className="mono" style={{color: "var(--red)", fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase", marginBottom: 12, marginTop: 24}}>Section 2 · Contact</div>
            <div style={{display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24}}>
              <div className="field"><label>Accounts payable contact <span className="req">*</span></label><input placeholder="Name" /></div>
              <div className="field"><label>AP email <span className="req">*</span></label><input type="email" placeholder="ap@acme.com" /></div>
              <div className="field"><label>Phone <span className="req">*</span></label><input placeholder="(555) 555-0123" /></div>
              <div className="field"><label>Desired credit limit</label><input placeholder="$25,000" /></div>
            </div>
            <div className="mono" style={{color: "var(--red)", fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase", marginBottom: 12, marginTop: 24}}>Section 3 · Trade References</div>
            <div className="field" style={{marginBottom: 16}}><label>Reference 1 (Company, contact, phone)</label><textarea style={{minHeight: 80}}></textarea></div>
            <div className="field" style={{marginBottom: 24}}><label>Reference 2 (Company, contact, phone)</label><textarea style={{minHeight: 80}}></textarea></div>
            <div style={{display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 24, borderTop: "1px solid var(--line)"}}>
              <div className="mono muted">Review takes 3-5 business days</div>
              <button className="btn btn-primary">Submit application <span className="arrow">→</span></button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
window.CreditAppPage = CreditAppPage;

function PoliciesPage() {
  const SECTIONS = [
    { h: "Ordering", ps: ["All orders require a signed proof and a 50% deposit to begin production. Balance is due net-30 for credit-approved clients, or upon delivery.", "Production lead times begin once we receive: approved proof, signed PO, deposit, and all necessary art files."] },
    { h: "Artwork & Proofs", ps: ["Please supply vector art (AI, EPS, PDF) whenever possible. We can convert raster art for a small fee, but vector is always preferred for print quality.", "Digital proofs are included with every order. Physical pre-production samples are available on request for an additional fee and lead time."] },
    { h: "Returns & Reprints", ps: ["Custom-decorated goods are non-returnable except in the case of a manufacturing defect or decoration error on our part.", "We stand behind our work. If you receive a defective item, notify us within 14 days of receipt and we'll reprint or refund at our discretion."] },
    { h: "Shipping", ps: ["Most orders ship FedEx Ground from Kitty Hawk, NC. Expedited shipping is available at cost.", "International shipping is available on request; duties and tariffs are the responsibility of the recipient."] },
    { h: "Cancellation", ps: ["Orders may be cancelled at no charge before art approval. After approval, you are responsible for any materials, setup, and decoration costs already incurred."] },
  ];
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / Policies</>} eye="Policies" title="The" titleIt="fine print." lede="Straightforward terms of service for ordering, proofing, shipping, and returns. No surprises." />
      <section className="sec">
        <div className="wrap" style={{maxWidth: 860}}>
          {SECTIONS.map((s, i) => (
            <div key={i} style={{borderTop: "1px solid var(--line)", padding: "40px 0"}}>
              <div style={{display: "grid", gridTemplateColumns: "80px 1fr", gap: 40, alignItems: "start"}}>
                <div className="mono" style={{color: "var(--red)"}}>{String(i+1).padStart(2, "0")}.</div>
                <div>
                  <h3 style={{fontFamily: "var(--serif)", fontSize: 40, letterSpacing: "-0.02em", marginBottom: 20}}>{s.h}</h3>
                  {s.ps.map((p, j) => <p key={j} style={{fontSize: 17, lineHeight: 1.6, color: "var(--ink-2)", marginBottom: 14}}>{p}</p>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.PoliciesPage = PoliciesPage;

function ProductSafetyPage() {
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / Product Safety</>} eye="Compliance" title="Product safety" titleIt="& compliance." lede="We take product safety seriously. Every item we sell meets U.S. consumer product safety regulations, and we maintain compliance documentation for every vendor in our catalog." />
      <section className="sec">
        <div className="wrap" style={{maxWidth: 860}}>
          {[
            { h: "CPSIA Compliance", p: "All children's products (intended for ages 12 and under) comply with the Consumer Product Safety Improvement Act. Test reports and general certificates of conformity are available on request." },
            { h: "Prop 65 (California)", p: "Products shipped to California are labeled in accordance with Proposition 65 where applicable. Warning labels identify any chemicals known to the State of California to cause cancer or reproductive harm." },
            { h: "FDA Food-Contact Items", p: "Drinkware and food-contact items in our catalog are FDA-approved for their intended use. Documentation is available upon request for any SKU." },
            { h: "Reporting a Concern", p: "If you believe a product we've sold presents a safety concern, please contact us immediately at safety@idyourself.com or 877.303.1049. We will investigate and respond within 24 hours." },
          ].map((s, i) => (
            <div key={i} style={{borderTop: "1px solid var(--line)", padding: "40px 0"}}>
              <div style={{display: "grid", gridTemplateColumns: "80px 1fr", gap: 40, alignItems: "start"}}>
                <div className="mono" style={{color: "var(--red)"}}>{String(i+1).padStart(2, "0")}.</div>
                <div>
                  <h3 style={{fontFamily: "var(--serif)", fontSize: 40, letterSpacing: "-0.02em", marginBottom: 20}}>{s.h}</h3>
                  <p style={{fontSize: 17, lineHeight: 1.6, color: "var(--ink-2)"}}>{s.p}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.ProductSafetyPage = ProductSafetyPage;
