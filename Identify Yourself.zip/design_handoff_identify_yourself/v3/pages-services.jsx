/* Services pages */

function ServicesIndex() {
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / Services</>} eye="What we do" title="Twelve services," titleIt="one identity crew." lede="Everything that goes into a polished brand moment — from the first sketch to the last shipment. Pick a service or send us the problem." wide />
      <section className="sec">
        <div className="wrap">
          <div className="services">
            {ID.SERVICES.map(s => <ServiceCard key={s.slug} s={s} />)}
          </div>
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.ServicesIndex = ServicesIndex;

function ServiceDetail({ slug }) {
  const s = ID.SERVICES.find(x => x.slug === slug);
  if (!s) return <div className="page-fade"><PageHero title="Not found" lede="That service doesn't exist." /></div>;
  const idx = ID.SERVICES.findIndex(x => x.slug === slug);
  const next = ID.SERVICES[(idx + 1) % ID.SERVICES.length];
  return (
    <div className="page-fade">
      <section className="page-hero wide">
        <div className="wrap">
          <div className="crumb mono"><Link to="home">Home</Link> / <Link to="services">Services</Link> / {s.title}</div>
          <div className="svc-detail-hero" style={{marginTop: 28}}>
            <div>
              <div className="eye mono" style={{display: "flex", alignItems: "center", gap: 14, color: "var(--muted)", marginBottom: 20}}>
                <span className="ldot" style={{width: 8, height: 8, borderRadius: "50%", background: "var(--red)"}}></span>
                Service {s.tag} of 12
              </div>
              <h1 style={{fontFamily: "var(--serif)", fontSize: "clamp(56px, 8vw, 112px)", lineHeight: 0.92, letterSpacing: "-0.03em", fontWeight: 400}}>
                {s.title.split(" ").slice(0, -1).join(" ")} <span className="it" style={{fontStyle: "italic", color: "var(--red)"}}>{s.title.split(" ").slice(-1)}</span>
              </h1>
              <p className="lede" style={{marginTop: 32, fontSize: 20, lineHeight: 1.5, maxWidth: 560, color: "var(--ink-2)"}}>{s.lede}</p>
              <div style={{marginTop: 32, display: "flex", gap: 10, flexWrap: "wrap"}}>
                <Link to="contact-us" className="btn btn-dark">Start a {s.title.toLowerCase()} project <span className="arrow">→</span></Link>
                <Link to="services" className="btn btn-ghost">All services</Link>
              </div>
            </div>
            <div className="visual">
              <div className={"placeholder " + s.fill} style={{opacity: 0.95}}></div>
              <div style={{position: "absolute", top: 20, left: 20, fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.14em", textTransform: "uppercase", color: "rgba(255,255,255,0.7)", background: "rgba(255,255,255,0.08)", padding: "6px 10px", borderRadius: 100, backdropFilter: "blur(6px)"}}>{s.tag} / {s.title}</div>
              <div style={{position: "absolute", bottom: 20, left: 20, right: 20, color: "#fff", display: "flex", justifyContent: "space-between", alignItems: "end"}}>
                <div style={{fontFamily: "var(--serif)", fontSize: 30, fontStyle: "italic", lineHeight: 1}}>{s.caption}</div>
                <div style={{fontFamily: "var(--mono)", fontSize: 10, opacity: 0.7, letterSpacing: "0.14em"}}>IMG / ref</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="sec" style={{paddingTop: 60}}>
        <div className="wrap">
          <div className="svc-features">
            {s.features.map(f => (
              <div key={f.n} className="svc-feature">
                <div className="n">{f.n}</div>
                <h3>{f.h}</h3>
                <p>{f.p}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="sec" style={{paddingTop: 20}}>
        <div className="wrap">
          <SecHead eye="Also explore" title="More things we" titleIt="make." />
          <div className="services">
            {ID.SERVICES.filter(x => x.slug !== s.slug).slice(0, 6).map(x => <ServiceCard key={x.slug} s={{...x, w: 4}} />)}
          </div>
          <div className="services-foot">
            <Link to={"services/" + next.slug} className="btn btn-dark">Next: {next.title} <span className="arrow">→</span></Link>
            <Link to="services" className="btn btn-ghost">All services</Link>
          </div>
        </div>
      </section>

      <ContactCTA />
    </div>
  );
}
window.ServiceDetail = ServiceDetail;

/* ---------- BRANDS WE CARRY ---------- */
function BrandsPage() {
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / Brands we carry</>} eye="Licensed to carry" title="The" titleIt="good stuff." lede="From premium performance apparel to everyday essentials — a vetted roster of 200+ vendors we work with directly, with full licensing and on-demand access." />
      <section className="sec">
        <div className="wrap">
          <BrandsGrid />
          <div className="services-foot" style={{marginTop: 32}}>
            <div className="mono muted">Plus 200+ more vendors on request. Can't find what you need? Ask.</div>
            <Link to="contact-us" className="btn btn-dark">Request a brand <span className="arrow">→</span></Link>
          </div>
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.BrandsPage = BrandsPage;

/* ---------- SHOP ---------- */
function ShopPage() {
  const [cat, setCat] = useState("All");
  const cats = ["All", ...Array.from(new Set(ID.PRODUCTS.map(p => p.cat)))];
  const list = cat === "All" ? ID.PRODUCTS : ID.PRODUCTS.filter(p => p.cat === cat);
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / Shop</>} eye="All products" title="Shop the" titleIt="catalog." lede="A curated selection of our greatest hits — ready to decorate with your brand. Click to request a quote, see samples, or customize." />
      <section className="sec">
        <div className="wrap">
          <div className="shop-top">
            <div className="filter-row">
              {cats.map(c => <div key={c} className={"chip" + (cat === c ? " on" : "")} style={{color: cat === c ? "#fff" : "var(--ink)", borderColor: cat === c ? "var(--red)" : "var(--line)"}} onClick={() => setCat(c)}>{c}</div>)}
            </div>
            <div className="mono muted">{list.length} products</div>
          </div>
          <div className="prod-grid">
            {list.map((p, i) => (
              <div key={i} className="prod">
                <div className="prod-img">
                  <div className={"placeholder " + p.fill}></div>
                  <div className="price-tag">{p.price}</div>
                  <div className="label">IMG / {p.cat}</div>
                </div>
                <div className="prod-info">
                  <div>
                    <div className="name">{p.name}</div>
                    <div className="sub">{p.sub}</div>
                  </div>
                  <div className="price">{p.price}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.ShopPage = ShopPage;

function SignaturePage() {
  return (
    <div className="page-fade">
      <PageHero crumb={<><Link to="home">Home</Link> / Shop / Signature Collection</>} eye="Signature Collection" title="Our in-house" titleIt="capsule." lede="Limited-edition apparel, drinkware, and accessories designed and decorated in-house — inspired by the coast, built for the road." />
      <section className="sec">
        <div className="wrap">
          <div className="prod-grid">
            {ID.PRODUCTS.slice(0, 8).map((p, i) => (
              <div key={i} className="prod">
                <div className="prod-img">
                  <div className={"placeholder " + p.fill}></div>
                  <div className="price-tag">{p.price}</div>
                  <div className="label">Signature · 001-{String(i+1).padStart(3,"0")}</div>
                </div>
                <div className="prod-info">
                  <div>
                    <div className="name">{p.name}</div>
                    <div className="sub">{p.sub}</div>
                  </div>
                  <div className="price">{p.price}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <ContactCTA />
    </div>
  );
}
window.SignaturePage = SignaturePage;
