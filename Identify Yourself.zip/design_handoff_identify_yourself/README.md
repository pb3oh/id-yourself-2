# Handoff: Identify Yourself — Website Rebuild

## Overview
This is a full rebuild of the **Identify Yourself** (idyourself.com) marketing website — a promotional products / branded merch agency based on the Outer Banks of North Carolina. The rebuild modernizes the site with an editorial, warm-modern aesthetic inspired by Icebox Cool Stuff, while preserving ID Yourself's signature red and the circular "id." logomark.

The deliverable is a **multi-page marketing site SPA** with ~20 routes covering home, about (4 subpages), services (index + 12 detail pages), brands, shop, signature collection, news, blog, contact, credit application, policies, and product safety.

## About the Design Files
The files in this bundle are **design references created in HTML/React-via-Babel** — prototypes showing intended look and behavior, **not production code to ship directly**.

Your task is to recreate these designs in the target codebase's environment using its established patterns (component library, routing, state management, CSS approach). If no environment exists yet, choose an appropriate stack — **Next.js 14 (App Router) + TypeScript + CSS Modules or Tailwind** is a good default for marketing sites of this type.

The prototype uses inline React + Babel standalone + a hash router for demo purposes only — production should use proper file-based routing, real components in separate files, and a build pipeline.

## Fidelity
**High-fidelity (hifi).** All colors, typography, spacing, animations, and copy are final. Recreate pixel-perfectly using the target codebase's conventions. Asset placeholders (striped fills on cards, brand wordmarks) should be replaced with real photography and real SVG logos from the partner brands listed.

## Site Map / Routes

| Route | Page | Purpose |
|---|---|---|
| `/` | Home | Hero, services grid, manifesto, process, testimonials, brands, contact CTA |
| `/about-us` | About | Company story, values, timeline |
| `/meet-the-crew` | Crew | 12 team members with dept filter |
| `/client-shout-outs` | Testimonials | Full testimonial list |
| `/careers` | Careers | Open roles + benefits |
| `/services` | Services index | All 12 services grid |
| `/services/:slug` | Service detail | One of 12 services (custom-apparel, company-merch, incentives-and-gifts, warehousing-and-custom-kitting, print-collateral-and-packaging, online-stores, awards-and-recognition, tradeshow-displays, creative-services, retail-merchandise, overseas-sourcing, large-format-printing) |
| `/brands-we-carry` | Brands | 24-brand wordmark grid |
| `/shop` | Shop | Product grid with category filter |
| `/signature-collection` | Signature Collection | Curated in-house product line |
| `/news` | News | 6 company news cards |
| `/blog` | Blog | 6 blog post cards |
| `/contact-us` | Contact | Form + contact cards |
| `/credit-application` | Credit App | Multi-section B2B credit form |
| `/policies` | Policies | Long-form policy copy |
| `/product-safety` | Product Safety | Compliance info |

## Global Shell

### Top Bar (sticky above nav)
- Height: auto, 10px vertical padding
- Background: `--ink` (#171312), text: #e9e3d8
- Left: animated red dot (`--red`) + "Now taking summer & Q4 swag projects"
- Right: location link · phone · email
- Font: JetBrains Mono, 11px, 0.14em letter-spacing, uppercase

### Nav (sticky, 48px horizontal padding, max-width 1440px)
- Background: `rgba(244,239,232,0.92)` with `backdrop-filter: blur(10px)`
- Border-bottom: 1px solid `--line` (#d9d0c3)
- Three-column grid: logo | centered nav items | CTA group
- **Logo**: circular 44×44 red mark containing italic serif "id." + stacked wordmark ("Identify Yourself" serif 20px + "Branded · Since 2004" mono 9px)
- **Nav items**: About / What We Do / News + Blog / Shop / Contact — each with hover dropdown menu (white bg, 1px border, 8px radius, 14px drop shadow)
- "What We Do" dropdown is wide (520px, 2-column) and includes all 12 services
- **CTA**: phone number (mono) + red pill "Get Started →" button

### Footer
- Background: `--ink`, text: `--bg`
- Giant serif "Identify Yourself." wordmark (clamp 80-220px)
- 4-column grid: HQ address + PPB badges | Services | About | Resources
- Bottom bar: copyright + 3 social circles (36×36, 1px border)

### Tweaks Panel (fixed bottom-right, 300px wide)
Hidden by default, toggled by host. Two controls:
- **Accent**: 5 color swatches (ID Red, Coastal, Sunrise, Forest, Plum)
- **Background**: 3 modes (Cream / Off-white / Sand)

## Design Tokens

### Colors
```css
--bg: #f4efe8;        /* cream page background */
--bg-2: #ece5db;      /* secondary cream */
--ink: #171312;       /* near-black text/dark sections */
--ink-2: #3a332f;     /* body text */
--muted: #6b615a;     /* muted text/labels */
--line: #d9d0c3;      /* borders/dividers */
--red: #c7372f;       /* ID signature red — primary accent */
--red-deep: #8f221c;  /* red hover */
--navy: #14202c;      /* deep coastal navy (manifesto bg) */
--sand: #d9c8a8;      /* warm tan */
--olive: #4a5240;     /* deep olive */
--cream: #f4efe8;     /* same as bg */
```

### Typography
- **Serif (display)**: Instrument Serif, 400 + italic. Used for H1, H2, section titles, testimonial quotes, logo wordmark.
- **Sans (body)**: Manrope, 400/500/600/700. Used for body text, nav, buttons.
- **Mono (labels)**: JetBrains Mono, 400/500. Used for eyebrows, meta labels, badges — always `font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase;`

### Type scale (all serif headings use `letter-spacing: -0.03em; line-height: 0.92`)
- Hero H1: `clamp(60px, 9.5vw, 140px)`
- Section H2: `clamp(44px, 6vw, 84px)`
- Page hero H1: `clamp(56px, 8vw, 128px)`
- Manifesto body: `clamp(28px, 3.2vw, 44px)`
- Testimonial quote: `clamp(28px, 3.4vw, 48px)`

Italic + red is the "voice" accent — apply to key phrases inside headings via `<span class="it">`.

### Spacing / Layout
- Content wrap: `max-width: 1440px` with `padding: 0 48px` (20px on mobile)
- Sections: `padding: 120px 0` (80px mobile)
- Dark sections (manifesto, contact): `padding: 140px 0`
- Grid gaps: 16-24px for cards, 60px between major columns

### Border radius
- Buttons/pills: `999px`
- Cards (services, products, posts): `6px`
- Larger cards/forms: `8-10px`

### Shadows
- Menu dropdown: `0 14px 40px rgba(0,0,0,0.08)`
- Red tape accent: `0 10px 30px rgba(199,55,47,0.35)`
- Tweaks panel: `0 20px 40px rgba(0,0,0,0.15)`

### Motion
- Standard transition: `0.2s ease` for colors, `0.3s ease` for transforms
- Service cards: `transform: translateY(-4px)` on hover; inner media scales to 1.04 over 0.6s
- Process rows: `padding-left: 12px` on hover + chevron rotates 45° and turns red
- Ticker: 40s linear infinite horizontal scroll
- Topbar dot: 2.2s blink animation

## Key Section Patterns

### Hero (home)
- 2-column grid (1.15fr : 1fr), aligned end
- Left: eyebrow line + H1 with italic red accent + sub + CTAs + 3-column stats (years/clients/products) separated by top border
- Right: tall 4:5 "visual" card with striped navy placeholder, "NOW SHIPPING" pill (top-left), rotated red "SINCE 2004" tape (top-right), italic serif caption (bottom)
- Below: mono marquee of categories with red ◆ separators

### Ticker
- Full-width band with top+bottom 1px borders
- Serif 36px italic running track, 56px gaps, red ★ separators, 40s loop

### Services grid (home + services index)
- 12-column CSS grid, 16px gap
- Card aspect ratio 4:5, 6px radius
- Sizing: cards carry `w-3 | w-4 | w-6` for grid-column spans
- Each card has striped fill (8 variants: `fill-navy`, `fill-red`, `fill-sand`, `fill-ink`, `fill-olive`, `fill-rust`, `fill-cream`, `fill-teal`) — these are placeholders for real product photography
- Overlay: bottom gradient to black 70%, pill tag top-left, serif title + mono caption bottom

### Manifesto (navy section)
- Background: `--navy`, text cream
- Absolute positioned giant serif number in corner at 4% opacity
- 2-column: label + big serif body copy with italic red emphasis words
- 4-column stats row at bottom with top border

### Process list
- Full-width rows separated by 1px lines
- 4-column grid: number (mono) | title (serif 40px) | description | chevron
- Hover: whole row indents 12px, chevron rotates 45° red, title turns red

### Testimonials
- Full-width red band (`--red`), text white
- Auto-advancing carousel, 7s interval
- Quote: serif clamp(28-48px), preceded by huge opening quote glyph at 40% opacity
- Dots (active is 32px pill) + round arrow buttons below

### Brands grid
- 6-column grid inside a 1px bordered card with inner 1px dividers
- Each cell is 2:1 aspect, wordmark rendered in one of 8 typographic styles (`lower-bold`, `serif-cap`, `thin-cap`, `block`, `serif`, `condensed`, `italic-bold`, `script`)
- Hover: cell inverts to ink background, scales 1.02, category label fades in
- **In production**: replace rendered text with actual brand SVG logos. A category tag is exposed as `data-cat` for filtering.

### Contact
- Ink background, 2-column grid
- Left: serif display copy with italic red accent + 3 contact cards (phone/email/address) with chevron arrows
- Right: form in translucent white card, mono uppercase labels above bottom-border inputs, chip row for "I'd like to discuss" selector, red submit pill

## Data

All demo content is in `data.js`. Structure:
- `ID.SERVICES` — 12 services with slug, title, tag, grid width, fill class, caption, lede, and 3 features each
- `ID.TESTIMONIALS` — 7 client quotes
- `ID.BRANDS` — 24 partner brands with name, category, typographic style
- `ID.CREW` — 12 team members with name, role, dept, ext, initials, fill
- `ID.SHOUT_OUTS` — extended testimonial list
- `ID.NEWS` — 6 news cards (cat, date, title, excerpt, fill)
- `ID.BLOG` — 6 blog posts (cat, date, title, excerpt, read time, fill)
- `ID.PRODUCTS` — 12 shop products (name, sub, price, cat, fill)
- `ID.FAQ` — 6 Q&A pairs

Replace this with a real CMS (Sanity, Contentful, or markdown + MDX) in production.

## State Management
Minimal — each page is largely static. What's needed:
- Hash-based router → replace with file-based routing (Next App Router)
- Testimonial carousel index (auto-advance + manual)
- Shop category filter
- Crew department filter
- Contact form state + "discussing" chip selector
- Tweaks panel (can drop in production, or ship as a real "switch theme" feature)

## Assets to replace
- **Logo**: keep the current "id." circular mark rendered in CSS, or produce a proper SVG version. The existing red + italic serif character combo is signature.
- **Service card placeholders** (striped fills) → real product photography (4:5 aspect)
- **Hero visual** (striped navy) → hero photo or looping video
- **Crew photos** (colored squares with initials) → real team portraits
- **Brand wordmarks** (rendered text) → real partner brand SVG logos — respect each brand's trademark guidelines
- **News/blog/product placeholders** (colored fills) → real imagery

## Responsive Breakpoints
- 1100px: hide nav links (mobile menu needed in prod), collapse service `w-*` to span 6
- 900px: hero becomes single column, contact form collapses to single column
- 860px: section heads stack, manifesto single column, stats become 2-col
- 720px: wrap padding drops to 20px, hide secondary topbar items

## Files in this handoff
- `Identify Yourself v3.html` — the main inlined prototype (loads everything)
- `v3/styles.css` — all styles (~360 lines)
- `v3/data.js` — site content
- `v3/shell.jsx` — Router, TopBar, Nav, Footer, Tweaks
- `v3/ui.jsx` — Shared primitives (PageHero, SecHead, Ticker, ServiceCard, TestimonialCarousel, BrandsGrid, ContactCTA)
- `v3/pages-home-about.jsx` — HomePage, AboutPage, CrewPage, ShoutOutsPage, CareersPage
- `v3/pages-services.jsx` — ServicesIndex, ServiceDetail, BrandsPage
- `v3/pages-content.jsx` — ShopPage, SignaturePage, NewsPage, BlogPage, ContactPage, CreditAppPage, PoliciesPage, ProductSafetyPage
- `Identify Yourself.html` — v1 (single-page landing)
- `Identify Yourself v2.html` — v2 (v1 + logo + brand grid polish)

Open `Identify Yourself v3.html` in a browser to view the full prototype.

## Suggested target stack
- **Next.js 14 App Router + TypeScript**
- **Tailwind** or CSS Modules (the current CSS is plain and ports cleanly to either)
- **next/font** for Instrument Serif / Manrope / JetBrains Mono
- **MDX or Sanity** for blog + news
- **Shopify or commerce-layer** for the shop (or keep it as inquiry-only)
- **Resend or Postmark** for the contact form submissions
